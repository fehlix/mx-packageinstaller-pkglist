<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Games
</category>

<name>
SuperTux
</name>

<description>
   <am>Mario style platform game w/ Tux</am>
   <ar>Mario style platform game w/ Tux</ar>
   <bg>Mario style platform game w/ Tux</bg>
   <bn>Mario style platform game w/ Tux</bn>
   <ca>Plataforma de jocs de l'estil Mario amb Tux</ca>
   <cs>Mario style platform game w/ Tux</cs>
   <da>Platformspil med Tux i stil med Mario</da>
   <de>Mario Style Plattformspiel mit Tux</de>
   <el>Mario style platform game w/ Tux</el>
   <en>Mario style platform game w/ Tux</en>
   <es>Juego de plataformas con Tux estilo Mario</es>
   <et>Mario style platform game w/ Tux</et>
   <eu>Mario style platform game w/ Tux</eu>
   <fa>Mario style platform game w/ Tux</fa>
   <fil_PH>Mario style platform game w/ Tux</fil_PH>
   <fi>Mario style platform game w/ Tux</fi>
   <fr>Jeu de plate-formes de style Mario, mais avec Tux comme héros</fr>
   <he_IL>Mario style platform game w/ Tux</he_IL>
   <hi>Mario style platform game w/ Tux</hi>
   <hr>Mario style platform game w/ Tux</hr>
   <hu>Mario style platform game w/ Tux</hu>
   <id>Mario style platform game w/ Tux</id>
   <is>Mario style platform game w/ Tux</is>
   <it>Piattaforma di gioco in stile SuperMario con la presenza del pinguino Tux</it>
   <ja_JP>Mario style platform game w/ Tux</ja_JP>
   <ja>Mario style platform game w/ Tux</ja>
   <kk>Mario style platform game w/ Tux</kk>
   <ko>Mario style platform game w/ Tux</ko>
   <lt>Mario style platform game w/ Tux</lt>
   <mk>Mario style platform game w/ Tux</mk>
   <mr>Mario style platform game w/ Tux</mr>
   <nb>Mario style platform game w/ Tux</nb>
   <nl>Mario stijl platform spel met Tux</nl>
   <pl>Gra platformowa w/ Tux w stylu Mario</pl>
   <pt_BR>Mario style platform game w/ Tux</pt_BR>
   <pt>Mario style platform game w/ Tux</pt>
   <ro>Mario style platform game w/ Tux</ro>
   <ru>Игра-платформер в духе Mario</ru>
   <sk>Mario style platform game w/ Tux</sk>
   <sl>Platformska igra tipa Mario z Tux</sl>
   <sq>Mario style platform game w/ Tux</sq>
   <sr>Mario style platform game w/ Tux</sr>
   <sv>Plattformsspel i Mariostil med Tux</sv>
   <tr>Mario style platform game w/ Tux</tr>
   <uk>Mario style platform game w/ Tux</uk>
   <vi>Mario style platform game w/ Tux</vi>
   <zh_CN>Mario style platform game w/ Tux</zh_CN>
   <zh_TW>Mario style platform game w/ Tux</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/shrine/screenshot/19360/simage/large-28ca72bd8597c8b25b8cf56bb52d7b59.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
supertux
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
supertux
</uninstall_package_names>
</app>
