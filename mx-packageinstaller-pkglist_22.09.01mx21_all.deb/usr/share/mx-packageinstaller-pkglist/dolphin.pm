<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
FileManagers
</category>

<name>
Dolphin
</name>

<description>
   <am> default file manager from the KDE plasma desktop</am>
   <ar> default file manager from the KDE plasma desktop</ar>
   <bg> default file manager from the KDE plasma desktop</bg>
   <bn> default file manager from the KDE plasma desktop</bn>
   <ca> default file manager from the KDE plasma desktop</ca>
   <cs> default file manager from the KDE plasma desktop</cs>
   <da> default file manager from the KDE plasma desktop</da>
   <de> default file manager from the KDE plasma desktop</de>
   <el> default file manager from the KDE plasma desktop</el>
   <en> default file manager from the KDE plasma desktop</en>
   <es> default file manager from the KDE plasma desktop</es>
   <et> default file manager from the KDE plasma desktop</et>
   <eu> default file manager from the KDE plasma desktop</eu>
   <fa> default file manager from the KDE plasma desktop</fa>
   <fil_PH> default file manager from the KDE plasma desktop</fil_PH>
   <fi> default file manager from the KDE plasma desktop</fi>
   <fr> default file manager from the KDE plasma desktop</fr>
   <he_IL> default file manager from the KDE plasma desktop</he_IL>
   <hi> default file manager from the KDE plasma desktop</hi>
   <hr> default file manager from the KDE plasma desktop</hr>
   <hu> default file manager from the KDE plasma desktop</hu>
   <id> default file manager from the KDE plasma desktop</id>
   <is> default file manager from the KDE plasma desktop</is>
   <it> default file manager from the KDE plasma desktop</it>
   <ja_JP> default file manager from the KDE plasma desktop</ja_JP>
   <ja> default file manager from the KDE plasma desktop</ja>
   <kk> default file manager from the KDE plasma desktop</kk>
   <ko> default file manager from the KDE plasma desktop</ko>
   <lt> default file manager from the KDE plasma desktop</lt>
   <mk> default file manager from the KDE plasma desktop</mk>
   <mr> default file manager from the KDE plasma desktop</mr>
   <nb> default file manager from the KDE plasma desktop</nb>
   <nl> default file manager from the KDE plasma desktop</nl>
   <pl> default file manager from the KDE plasma desktop</pl>
   <pt_BR> default file manager from the KDE plasma desktop</pt_BR>
   <pt> default file manager from the KDE plasma desktop</pt>
   <ro> default file manager from the KDE plasma desktop</ro>
   <ru> default file manager from the KDE plasma desktop</ru>
   <sk> default file manager from the KDE plasma desktop</sk>
   <sl> default file manager from the KDE plasma desktop</sl>
   <sq> default file manager from the KDE plasma desktop</sq>
   <sr> default file manager from the KDE plasma desktop</sr>
   <sv> default file manager from the KDE plasma desktop</sv>
   <tr> default file manager from the KDE plasma desktop</tr>
   <uk> default file manager from the KDE plasma desktop</uk>
   <vi> default file manager from the KDE plasma desktop</vi>
   <zh_CN> default file manager from the KDE plasma desktop</zh_CN>
   <zh_TW> default file manager from the KDE plasma desktop</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/shrine/screenshot/14863/simage/large-fd15a4ccfdf71e01f83f9dcffe13b1cd.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
dolphin
kde-servicemenu-rootactions
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
dolphin
kde-servicemenu-rootactions
</uninstall_package_names>
</app>
