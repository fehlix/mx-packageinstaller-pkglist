<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Language
</category>

<name>
Ukrainian_Firefox
</name>

<description>
   <am>Ukrainian localisation of Firefox</am>
   <ar>Ukrainian localisation of Firefox</ar>
   <bg>Ukrainian localisation of Firefox</bg>
   <bn>Ukrainian localisation of Firefox</bn>
   <ca>Localització de Firefox en Ucrainès</ca>
   <cs>Ukrainian localisation of Firefox</cs>
   <da>Ukrainsk oversættelse af Firefox</da>
   <de>Ukrainische Lokalisierung von Firefox</de>
   <el>Ουκρανικός εντοπισμός του Firefox</el>
   <en>Ukrainian localisation of Firefox</en>
   <es>Localización Ucraniana de Firefox</es>
   <et>Ukrainian localisation of Firefox</et>
   <eu>Ukrainian localisation of Firefox</eu>
   <fa>Ukrainian localisation of Firefox</fa>
   <fil_PH>Ukrainian localisation of Firefox</fil_PH>
   <fi>Ukrainian localisation of Firefox</fi>
   <fr>Localisation ukrainienne pour Firefox</fr>
   <he_IL>Ukrainian localisation of Firefox</he_IL>
   <hi>Ukrainian localisation of Firefox</hi>
   <hr>Ukrainian localisation of Firefox</hr>
   <hu>Ukrainian localisation of Firefox</hu>
   <id>Ukrainian localisation of Firefox</id>
   <is>Ukrainian localisation of Firefox</is>
   <it>Localizzazione ucraina di Firefox</it>
   <ja_JP>Ukrainian localisation of Firefox</ja_JP>
   <ja>Ukrainian localisation of Firefox</ja>
   <kk>Ukrainian localisation of Firefox</kk>
   <ko>Ukrainian localisation of Firefox</ko>
   <lt>Ukrainian localisation of Firefox</lt>
   <mk>Ukrainian localisation of Firefox</mk>
   <mr>Ukrainian localisation of Firefox</mr>
   <nb>Ukrainian localisation of Firefox</nb>
   <nl>Oekraïense lokalisatie van Firefox</nl>
   <pl>Ukraińska lokalizacja przeglądarki Firefox</pl>
   <pt_BR>Ucraniano Localização para Firefox</pt_BR>
   <pt>Ucraniano Localização para Firefox</pt>
   <ro>Ukrainian localisation of Firefox</ro>
   <ru>Украинская локализация Firefox</ru>
   <sk>Ukrainian localisation of Firefox</sk>
   <sl>Ukrainian localisation of Firefox</sl>
   <sq>Ukrainian localisation of Firefox</sq>
   <sr>Ukrainian localisation of Firefox</sr>
   <sv>Ukrainsk lokalisering av Firefox</sv>
   <tr>Firefox'un Ukraynaca yerelleştirmesi</tr>
   <uk>Ukrainian localisation of Firefox</uk>
   <vi>Ukrainian localisation of Firefox</vi>
   <zh_CN>Ukrainian localisation of Firefox</zh_CN>
   <zh_TW>Ukrainian localisation of Firefox</zh_TW>
</description>

<installable>
32,64
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-uk
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-uk
</uninstall_package_names>
</app>
