<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Browser
</category>

<name>
Falkon
</name>

<description>
   <am>Latest Falkon lightweight browser</am>
   <ar>Latest Falkon lightweight browser</ar>
   <bg>Latest Falkon lightweight browser</bg>
   <bn>Latest Falkon lightweight browser</bn>
   <ca>El darrer navegador lleuger Falkon</ca>
   <cs>Latest Falkon lightweight browser</cs>
   <da>Seneste Falkon letvægtsbrowser</da>
   <de>Neuester Falkon leichtgewichtiger Browser</de>
   <el>Τελευταίο ελαφρύ πρόγραμμα περιήγησης Falkon</el>
   <en>Latest Falkon lightweight browser</en>
   <es>Último navegador ligero Falkon</es>
   <et>Latest Falkon lightweight browser</et>
   <eu>Latest Falkon lightweight browser</eu>
   <fa>Latest Falkon lightweight browser</fa>
   <fil_PH>Latest Falkon lightweight browser</fil_PH>
   <fi>Latest Falkon lightweight browser</fi>
   <fr>Dernière version du navigateur léger Falkon</fr>
   <he_IL>Latest Falkon lightweight browser</he_IL>
   <hi>Latest Falkon lightweight browser</hi>
   <hr>Latest Falkon lightweight browser</hr>
   <hu>Latest Falkon lightweight browser</hu>
   <id>Latest Falkon lightweight browser</id>
   <is>Latest Falkon lightweight browser</is>
   <it>Ultimo browser leggero Falkon</it>
   <ja_JP>Latest Falkon lightweight browser</ja_JP>
   <ja>Latest Falkon lightweight browser</ja>
   <kk>Latest Falkon lightweight browser</kk>
   <ko>Latest Falkon lightweight browser</ko>
   <lt>Latest Falkon lightweight browser</lt>
   <mk>Latest Falkon lightweight browser</mk>
   <mr>Latest Falkon lightweight browser</mr>
   <nb>Latest Falkon lightweight browser</nb>
   <nl>Nieuwste Falkon lichtgewicht browser</nl>
   <pl>najnowsza lekka przeglądarka Falkon</pl>
   <pt_BR>Navegador web ligeiro Falkon, versão mais recente</pt_BR>
   <pt>Versão mais recente do navegador ligeiro Falkon</pt>
   <ro>Latest Falkon lightweight browser</ro>
   <ru>Свежий релиз облегченного браузера Falkon</ru>
   <sk>Latest Falkon lightweight browser</sk>
   <sl>Zadnja različica lahkega brskalnika Falkon</sl>
   <sq>Latest Falkon lightweight browser</sq>
   <sr>Latest Falkon lightweight browser</sr>
   <sv>Senaste Falkon lättviktswebbläsare</sv>
   <tr>En son Falcon hafif tarayıcı</tr>
   <uk>Latest Falkon lightweight browser</uk>
   <vi>Latest Falkon lightweight browser</vi>
   <zh_CN>Latest Falkon lightweight browser</zh_CN>
   <zh_TW>Latest Falkon lightweight browser</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/017/192/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
falkon
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
falkon
</uninstall_package_names>
</app>
