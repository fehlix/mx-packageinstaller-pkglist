<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Audio
</category>

<name>
DeaDBeeF
</name>

<description>
   <am>simple audio player</am>
   <ar>simple audio player</ar>
   <bg>simple audio player</bg>
   <bn>simple audio player</bn>
   <ca>senzill reproductor d'àudio</ca>
   <cs>simple audio player</cs>
   <da>Simpel lydafspiller</da>
   <de>Einfacher Audio-Player</de>
   <el>απλή συσκευή αναπαραγωγής ήχου</el>
   <en>simple audio player</en>
   <es>Reproductor de audio sencillo</es>
   <et>simple audio player</et>
   <eu>simple audio player</eu>
   <fa>simple audio player</fa>
   <fil_PH>simple audio player</fil_PH>
   <fi>simple audio player</fi>
   <fr>Lecteur audio basique</fr>
   <he_IL>simple audio player</he_IL>
   <hi>simple audio player</hi>
   <hr>simple audio player</hr>
   <hu>simple audio player</hu>
   <id>simple audio player</id>
   <is>simple audio player</is>
   <it>Lettore di tracce audio semplice</it>
   <ja_JP>simple audio player</ja_JP>
   <ja>simple audio player</ja>
   <kk>simple audio player</kk>
   <ko>simple audio player</ko>
   <lt>paprastas garso grotuvas</lt>
   <mk>simple audio player</mk>
   <mr>simple audio player</mr>
   <nb>simple audio player</nb>
   <nl>eenvoudige audio speler</nl>
   <pl>prosty odtwarzacz audio</pl>
   <pt_BR>Reprodutor de áudio muito simples</pt_BR>
   <pt>Reprodutor de áudio simples e de fácil utilização</pt>
   <ro>simple audio player</ro>
   <ru>Музыкальный проигрыватель</ru>
   <sk>jednoduchý zvukový prehrávač</sk>
   <sl>preprost predvajalnik zvoka</sl>
   <sq>simple audio player</sq>
   <sr>simple audio player</sr>
   <sv>enkel ljudspelare</sv>
   <tr>simple audio player</tr>
   <uk>простий аудіо програвач</uk>
   <vi>simple audio player</vi>
   <zh_CN>simple audio player</zh_CN>
   <zh_TW>simple audio player</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>http://deadbeef.sourceforge.net/screenshots/0.6/06.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
deadbeef
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
deadbeef
</uninstall_package_names>
</app>
