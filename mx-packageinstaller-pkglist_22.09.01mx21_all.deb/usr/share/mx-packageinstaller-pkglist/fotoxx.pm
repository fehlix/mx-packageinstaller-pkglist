<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Graphics
</category>

<name>
fotoxx
</name>

<description>
   Manage and edit a large collection of photos
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/shrine/screenshot/simage/large-8433a80005bf9101c6cf62c46e303656.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
fotoxx
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
fotoxx
</uninstall_package_names>
</app>
