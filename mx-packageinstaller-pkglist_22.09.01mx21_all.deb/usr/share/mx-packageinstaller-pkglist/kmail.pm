<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Email
</category>

<name>
Kmail
</name>

<description>
   <am>Email client from the KDE Community</am>
   <ar>Email client from the KDE Community</ar>
   <bg>Email client from the KDE Community</bg>
   <bn>Email client from the KDE Community</bn>
   <ca>Email client from the KDE Community</ca>
   <cs>Email client from the KDE Community</cs>
   <da>Email client from the KDE Community</da>
   <de>Email client from the KDE Community</de>
   <el>Email client from the KDE Community</el>
   <en>Email client from the KDE Community</en>
   <es>Email client from the KDE Community</es>
   <et>Email client from the KDE Community</et>
   <eu>Email client from the KDE Community</eu>
   <fa>Email client from the KDE Community</fa>
   <fil_PH>Email client from the KDE Community</fil_PH>
   <fi>Email client from the KDE Community</fi>
   <fr>Email client from the KDE Community</fr>
   <he_IL>Email client from the KDE Community</he_IL>
   <hi>Email client from the KDE Community</hi>
   <hr>Email client from the KDE Community</hr>
   <hu>Email client from the KDE Community</hu>
   <id>Email client from the KDE Community</id>
   <is>Email client from the KDE Community</is>
   <it>Email client from the KDE Community</it>
   <ja_JP>Email client from the KDE Community</ja_JP>
   <ja>Email client from the KDE Community</ja>
   <kk>Email client from the KDE Community</kk>
   <ko>Email client from the KDE Community</ko>
   <lt>Email client from the KDE Community</lt>
   <mk>Email client from the KDE Community</mk>
   <mr>Email client from the KDE Community</mr>
   <nb>Email client from the KDE Community</nb>
   <nl>Email client from the KDE Community</nl>
   <pl>Email client from the KDE Community</pl>
   <pt_BR>Email client from the KDE Community</pt_BR>
   <pt>Email client from the KDE Community</pt>
   <ro>Email client from the KDE Community</ro>
   <ru>Email client from the KDE Community</ru>
   <sk>Email client from the KDE Community</sk>
   <sl>Email client from the KDE Community</sl>
   <sq>Email client from the KDE Community</sq>
   <sr>Email client from the KDE Community</sr>
   <sv>Email client from the KDE Community</sv>
   <tr>Email client from the KDE Community</tr>
   <uk>Email client from the KDE Community</uk>
   <vi>Email client from the KDE Community</vi>
   <zh_CN>Email client from the KDE Community</zh_CN>
   <zh_TW>Email client from the KDE Community</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/shrine/screenshot/15282/simage/large-a66c9ca83457d7c6142dd4b2b560388c.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
kmail
accountwizard 
kdepim-themeeditors 
libkf5mailimporterakonadi5
mbox-importer
pim-data-exporter 
pim-sieve-editor
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
kmail
</uninstall_package_names>
</app>
