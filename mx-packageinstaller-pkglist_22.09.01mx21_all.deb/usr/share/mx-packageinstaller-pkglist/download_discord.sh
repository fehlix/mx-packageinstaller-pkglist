#!/bin/bash

#download discord
#part of mx-packageinstaller

wget -O /tmp/discord.deb "https://discordapp.com/api/download?platform=linux&format=deb"

exit 0
