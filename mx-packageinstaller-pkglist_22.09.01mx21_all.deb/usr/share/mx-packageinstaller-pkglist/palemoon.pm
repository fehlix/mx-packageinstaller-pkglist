<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Browser
</category>

<name>
Palemoon
</name>

<description>
   <am>Palemoon from the mx repo</am>
   <ar>Palemoon from the mx repo</ar>
   <bg>Palemoon from the mx repo</bg>
   <bn>Palemoon from the mx repo</bn>
   <ca>Palemoon del dipòsit de MX</ca>
   <cs>Palemoon from the mx repo</cs>
   <da>Palemoon mx-softwarekilden</da>
   <de>Pale Moon aus dem MX-Repo</de>
   <el>Palemoon από το mx repo</el>
   <en>Palemoon from the mx repo</en>
   <es>Palemoon desde el repositorio de MX</es>
   <et>Palemoon from the mx repo</et>
   <eu>Palemoon from the mx repo</eu>
   <fa>Palemoon from the mx repo</fa>
   <fil_PH>Palemoon from the mx repo</fil_PH>
   <fi>Palemoon from the mx repo</fi>
   <fr>Palemoon du dépôt MX</fr>
   <he_IL>Palemoon from the mx repo</he_IL>
   <hi>Palemoon from the mx repo</hi>
   <hr>Palemoon from the mx repo</hr>
   <hu>Palemoon from the mx repo</hu>
   <id>Palemoon from the mx repo</id>
   <is>Palemoon from the mx repo</is>
   <it>Palemoon dal repo mx</it>
   <ja_JP>Palemoon from the mx repo</ja_JP>
   <ja>Palemoon from the mx repo</ja>
   <kk>Palemoon from the mx repo</kk>
   <ko>Palemoon from the mx repo</ko>
   <lt>Palemoon iš mx saugyklos</lt>
   <mk>Palemoon from the mx repo</mk>
   <mr>Palemoon from the mx repo</mr>
   <nb>Palemoon from the mx repo</nb>
   <nl>Palemoon uit de mx pakketbron</nl>
   <pl>Palemoon z repozytorium MX</pl>
   <pt_BR>Navegador web Palemoon do repositório mx repo</pt_BR>
   <pt>Navegador web Palemoon do repositório mx repo</pt>
   <ro>Palemoon from the mx repo</ro>
   <ru>Браузер Palemoon из репозитория mx</ru>
   <sk>Palemoon from the mx repo</sk>
   <sl>Palemoon iz mx repozitorija</sl>
   <sq>Palemoon from the mx repo</sq>
   <sr>Palemoon from the mx repo</sr>
   <sv>Palemoon från mx repo</sv>
   <tr>Palemoon from the mx repo</tr>
   <uk>Palemoon зі сховища mx</uk>
   <vi>Palemoon from the mx repo</vi>
   <zh_CN>Palemoon from the mx repo</zh_CN>
   <zh_TW>Palemoon from the mx repo</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>http://www.palemoon.org/images/screenshots/Win10-start-portal-th.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
palemoon
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
palemoon
</uninstall_package_names>
</app>
