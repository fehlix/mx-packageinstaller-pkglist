<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Audio
</category>

<name>
PulseEffects
</name>

<description>
   pulseaudio equalizer
</description>

<installable>
all
</installable>

<screenshot></screenshot>

<preinstall>

</preinstall>

<install_package_names>
pulseeffects
calf-plugins
gstreamer1.0-autogain-pulseeffects
gstreamer1.0-convolver-pulseeffects
gstreamer1.0-crystalizer-pulseeffects
liblilv-0-0
lsp-plugins
rubberband-ladspa
zam-plugins
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
pulseeffects
gstreamer1.0-autogain-pulseeffects
gstreamer1.0-convolver-pulseeffects
gstreamer1.0-crystalizer-pulseeffects
</uninstall_package_names>
</app>
